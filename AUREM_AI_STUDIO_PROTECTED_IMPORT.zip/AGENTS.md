# AUREM — Agent instructions

The complete source-preserving import and no-change rules are in `AUREM_IMPORT_START_HERE.md` and apply to every file in this project.
This is an EXISTING Kotlin/Android/WebView app. Never silently rebuild it as a different architecture.
Do not modify old features or pricing unless the owner requests specific changes.
When import/preview is incompatible, disclose the limitation instead of producing a similar-looking replacement.
