# AUREM — STRICT SOURCE-PRESERVING IMPORT

## READ FIRST — DO NOT RECREATE THIS APP

This ZIP is the ACTUAL pre-existing Android project. It is **NOT** a specification to generate a new or similar app.

**First action:** import/restore the existing project as-is and inspect the files. Do not regenerate an approximation. If this environment cannot run the unchanged existing Kotlin + XML + WebView project, state that explicitly and STOP instead of silently converting it to Compose or React.

**Baseline:** Android package `com.aurem.app`, versionName `1.1.0`, versionCode `2`.
**Architecture:** Kotlin native Android WebView shell + Android bridge, bundled HTML/CSS/JavaScript UI. Local UI loads at `https://appassets.androidplatform.net/assets/index.html`. This is not a React/TypeScript app.

## Non-negotiable preservation rules

1. Do NOT edit any existing source file, pricing logic, native bridge, data model, storage key, string, layout, font, icon, design, board dimensions, or print behavior just to make a preview look right.
2. Do NOT replace the existing HTML/CSS/JS user interface with a newly generated Compose or web UI. Do NOT guess or recreate it from screenshots.
3. Do NOT simplify, optimize, refactor, rename, or remove a working feature.
4. Do NOT change the `com.aurem.app` application ID, app version, current WebView wiring, or persistence format.
5. Do NOT change existing Core/Non-Core pricing rules. Core `boardFormat()` in `app/src/main/assets/core.js` and Non-Core `nBoard()` in `app/src/main/assets/noncore.js` are separate.
6. Do NOT change board SVG, print geometry, Page Saver, star/focus rules, local IndexedDB, EAN matching, camera, OCR, file selection, or PDF generation.
7. Do not repair any previously existing defect unless the owner explicitly asks for the particular fix.
8. When the user later requests a feature, present a risk assessment and list of files before changing anything; isolate additive logic, then verify unchanged behavior.

## Source of truth: what to load

- `app/src/main/java/com/aurem/app/MainActivity.kt` — Android WebView setup, permissions, and native integration.
- `app/src/main/java/com/aurem/app/AUREMAndroidBridge.kt` — native Android feature bridge.
- `app/src/main/java/com/aurem/app/PdfPrintDocumentAdapter.kt` — native printing.
- `app/src/main/assets/index.html` — **EXISTING actual UI entry point** (not a design mockup).
- `app/src/main/assets/style.css`, `noncore.css`, `inventory.css`, `studio.css` — exact styling.
- `app/src/main/assets/app.js` — Core workflow and app state.
- `app/src/main/assets/core.js` — REG-STAT parser and Core pricing algorithm.
- `app/src/main/assets/noncore.js` — Non-Core workflow and price boards.
- `app/src/main/assets/preview.js` — Core board SVG/print layout.
- `app/src/main/assets/{inventory,studio,loose_grocery,notebook_boards,smart_replica,migration,verified}.js` — additional existing capabilities.
- `app/src/main/res/` — current icons, Android layouts, and resources.
- `app/build.gradle.kts`, `settings.gradle.kts`, `gradle/libs.versions.toml` — existing Android build configuration.
- `app/src/main/assets/review_previews/` — historical visual regression references; **not** a license to redesign the app.
- `public/assets/aistudio/` — retained original attached reference data/images except an older nested source ZIP.
- `cloudflare/worker.js` — original separate service code. Do not replace server interactions with invented code.

## Pricing rules (must not change)

### CORE `boardFormat()` precedence
1. Invalid MRP/SP, or SP >= MRP: REVIEW, do not print.
2. Integer-cent SP * 3 == MRP: B1G2 (BUY 1 GET 2 FREE).
3. Integer-cent SP * 2 == MRP: B1G1 (BUY 1 GET 1 FREE).
4. Discount from Rs. 1 to Rs. 3 inclusive: ONLY.
5. Permanent-list item: percentage OFF (percentage floored).
6. SP below half MRP: ONLY.
7. Edible oil, raw grocery, or ghee: ONLY.
8. Otherwise: rupee-discount OFF.

### NON-CORE
Separate `noncore.js` implementation; boards show selling price ONLY with designated footer option. Do not reuse the CORE pricing engine for NON-CORE.

## Board format preservation

CORE: 1/20, 1/9, 1/8, 1/4, 1/3, 1/2, 1/1.
NON-CORE: 1/20, 1/9, 1/8, 1/6, 1/5, 1/4, 1/3, 1/2, 1/1.
Keep existing orientation, pagination, physical dimensions, and standard/Page Saver logic as actually coded. Core Focus uses yellow paper; non-Focus white. Do not redesign boards.

## Before showing any result

1. Identify whether you actually IMPORTED the unchanged source or GENERATIVELY REBUILT it.
2. Compare all unchanged source files against `AUREM_IMPORT_SOURCE_SHA256.json` in this ZIP. Every listed retained original file must have the exact same bytes. Newly added documentation files are not part of baseline.
3. If imported source can't run in this tool, say "cannot run unchanged AUREM architecture" rather than claim success.
4. Do not claim a matching emulator screen proves native camera, OCR, sign-in, PDF, or printing work; those require device testing.

**Source is authoritative. No feature changes are authorized by the import.**
